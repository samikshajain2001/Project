import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import ShowList from './ShowList';
import ShowDetails from './ShowDetails';
import BookTicket from './BookTicket';

const App = () => {
  const [shows, setShows] = useState([]);

  useEffect(() => {
    fetch('https://api.tvmaze.com/search/shows?q=all')
      .then((response) => response.json())
      .then((data) => setShows(data));
  }, []);

  return (
    <Router>
      <div className="container">
        <header>
          <h1>TV Shows</h1>
        </header>
        <Switch className="design" >
          <Route exact path="/">
            <ShowList shows={shows} />
          </Route>
          <Route path="/book-ticket/:id">
            <BookTicket />
          </Route>
          <Route path="/details/:id">
            <ShowDetails />
          </Route>
        </Switch>
      </div>
    </Router>
  );
};

export default App;

